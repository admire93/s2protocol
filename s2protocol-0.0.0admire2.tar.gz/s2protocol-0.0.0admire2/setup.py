# -*- coding: utf-8 -*-
from setuptools import setup, find_packages

setup(name='s2protocol',
      version='0.0.0',
      author='Blizzard',
      install_requires=[
          'mpyq'
      ],
      packages=find_packages())
